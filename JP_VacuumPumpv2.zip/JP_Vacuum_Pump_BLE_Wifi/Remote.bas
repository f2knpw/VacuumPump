﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Service
Version=7.3
@EndOfDesignText@
#Region  Service Attributes 
	#StartAtBoot: False
	
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Dim UDPnok As Int = 0
	Dim FirstConnection As Boolean = True
	Dim UDPSocket1 As UDPSocket

	Dim Timer1 As Timer
	Dim Timer2 As Timer
	
	Dim DestAddress As String = "0.0.0.0"

	Dim SSID As String
	Dim Password As String
	Dim EditVal As String
	Dim AskTopic As Int = 0

End Sub

Sub Service_Create
	UDPSocket1.Initialize("UDP", 5000, 1000)
	

	Timer2.Initialize("Timer2", 5000) 	'heartbeat to check UDP connection

End Sub

Sub Service_Start (StartingIntent As Intent)
	Timer2.Enabled = True
	
	UDPConnect
End Sub

Sub Service_Destroy
	Try
		Timer2.Enabled = False
		UDPSocket1.Close
	Catch
		Log(LastException)
	End Try
	
End Sub

Sub UDP_PacketArrived (Packet As UDPPacket)
	Dim msg As String
	UDPnok = 0	'reset UDP bad connection counter
	msg = BytesToString(Packet.Data, Packet.Offset, Packet.Length, "UTF8")
	Log(msg)

	Select msg
	
		Case "eVacuumPump"
			AskTopic = 0	'will ask again "TOPIC" in 20s
			DestAddress = Packet.HostAddress
			If FirstConnection Then
				FirstConnection = False
				Log(DestAddress)
				Main.ip = DestAddress
				EditVal = "TOPIC"
				SendUDP(EditVal)
			
			End If
		Case "okSSID"
			EditVal = "PASS :" & Password
			SendUDP(EditVal)
		Case "okPASS"
			ToastMessageShow("Wifi config Ok...  restart App now.", True)
			'Activity.Finish
		Case "okMESS"
			ToastMessageShow("Message registration Ok...  ", True)
			'Activity.Finish
		Case "okSTOP"
			ToastMessageShow("restart App now.", True)
			'Activity.Finish
		Case Else
			Try										'{"sender":"A020A6104501","device":"eCatFeeder"}
				Dim parser As JSONParser
				parser.Initialize(msg)
				Dim root As Map = parser.NextObject				
				
				Main.pressure = root.Get("P") 'takes into account ideal diode drop out
				Main.HighPressure  = root.Get("H")
				Main.LowPressure  = root.Get("L")
				Main.pumpStatus = root.Get("S")
				Main.onTime = root.Get("Run")
				msg = ""
				If (Main.isactive) Then CallSub(Main, "DrawLine")
				
				
			Catch
				Log(LastException.Message)
			End Try
	End Select
End Sub

Sub UDPConnect
	Dim Packet As UDPPacket
	Dim Dest As String
    Dim data() As Byte
    data = "ID".GetBytes("UTF8")
	Dest = DestAddress
	If (Dest.StartsWith("0.0.0.0")) Then Dest = "255.255.255.255"
    Packet.Initialize(data, Dest, 5000)
    UDPSocket1.Send(Packet)
End Sub
Sub UDPreConnect()
	Try
	UDPSocket1.Close
	UDPSocket1.Initialize("UDP", 5000, 1000)
	DestAddress = "0.0.0.0"
	UDPConnect
	Catch
		Log(LastException)
	End Try
End Sub
Sub SendUDP(MyStr As String)
	Dim Packet As UDPPacket
	Dim Dest As String
    Dim data() As Byte

    data = (MyStr).GetBytes("UTF8")
	Dest = DestAddress
    Packet.Initialize(data, Dest, 5000)
    UDPSocket1.Send(Packet)
End Sub

Sub Timer2_Tick
	UDPConnect 	'connect message to "heartBeat" the connection
	If UDPnok > 4 Then				'if multiple failures then reconnect
		UDPreConnect
	End If
	UDPnok = UDPnok+1
	AskTopic = AskTopic+1
	If AskTopic > 10 Then FirstConnection = True 'will ask for topic next time
End Sub
Sub SendEditVal
	SendUDP(EditVal)
End Sub


